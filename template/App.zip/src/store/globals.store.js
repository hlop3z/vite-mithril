const data = {
  count: 0,
};

const ctrl = {
  add() {
    data.count += 1;
  },
};

export default {
  data,
  ctrl,
};
